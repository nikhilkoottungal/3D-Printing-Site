<?php
/* Copyright (C) 2010-2011	Regis Houssin <regis.houssin@inodbox.com>
 * Copyright (C) 2013		Juanjo Menent <jmenent@2byte.es>
 * Copyright (C) 2014       Marcos García <marcosgdf@gmail.com>
 * Copyright (C) 2024		MDW							<mdeweerd@users.noreply.github.com>
 * Copyright (C) 2024       Frédéric France         <frederic.france@free.fr>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *  \file		htdocs/asset/tpl/linkedobjectblock.tpl.php
 *  \ingroup	asset
 *  \brief		Template to show objects linked to assets
 */

/**
 * @var Translate $langs
 * @var Conf $conf
 * @var User $user
 *
 * @var CommonObject $object
 * @var int $noMoreLinkedObjectBlockAfter
 * @var int $showImportButton
 * @var Propal[] $linkedObjectBlock
 */

// Protection to avoid direct call of template
if (empty($conf) || !is_object($conf)) {
	print "Error, template page can't be called as URL";
	exit(1);
}


print "<!-- BEGIN PHP TEMPLATE commande/tpl/linkedobjectblock.tpl.php -->\n";

// Load translation files required by the page
$langs->load("assets");

$linkedObjectBlock = dol_sort_array($linkedObjectBlock, 'date,ref', 'desc', 0, 0, 1);
'@phan-var-force Asset[] $linkedObjectBlock';  // Repeat because type lost after dol_sort_array)
/** @var Asset[] $linkedObjectBlock */

$total = 0;
$ilink = 0;
foreach ($linkedObjectBlock as $key => $objectlink) {
	$ilink++;

	$trclass = 'oddeven';
	if ($ilink == count($linkedObjectBlock) && empty($noMoreLinkedObjectBlockAfter) && count($linkedObjectBlock) <= 1) {
		$trclass .= ' liste_sub_total';
	}
	echo '<tr class="'.$trclass.'" >';
	echo '<td class="linkedcol-element tdoverflowmax100">'.$langs->trans("Asset");
	if (!empty($showImportButton) && getDolGlobalString('MAIN_ENABLE_IMPORT_LINKED_OBJECT_LINES')) {
		print '<a class="objectlinked_importbtn" href="'.$objectlink->getNomUrl(0, '', 0, 1).'&action=selectlines&token='.newToken().'" data-element="'.$objectlink->element.'" data-id="'.$objectlink->id.'"> <i class="fa fa-indent"></i> </a>';
	}
	echo '</td>';
	echo '<td class="linkedcol-name tdoverflowmax150" >'.$objectlink->getNomUrl(1).'</td>';
	echo '<td class="linkedcol-ref tdoverflowmax150" title="'.dolPrintHTMLForAttribute($objectlink->label).'">'.dolPrintHTML($objectlink->label).'</td>';
	echo '<td class="linkedcol-date center">'.dol_print_date($objectlink->date_start, 'day').'</td>';
	echo '<td class="linkedcol-amount right">';
	if ($user->hasRight('asset', 'read')) {
		$total += $objectlink->acquisition_value_ht;
		echo price($objectlink->acquisition_value_ht);
	}
	echo '</td>';
	echo '<td class="linkedcol-statut right">'.$objectlink->getLibStatut(3).'</td>';
	echo '<td class="linkedcol-action right">';
	echo '<a class="reposition" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=dellink&token='.newToken().'&dellinkid='.$key.'">'.img_picto($langs->transnoentitiesnoconv("RemoveLink"), 'unlink').'</a>';
	echo '</td>';
	echo "</tr>\n";
}
if (count($linkedObjectBlock) > 1) {
	echo '<tr class="liste_total '.(empty($noMoreLinkedObjectBlockAfter) ? 'liste_sub_total' : '').'">';
	echo '<td>'.$langs->trans("Total").'</td>';
	echo '<td></td>';
	echo '<td class="center"></td>';
	echo '<td class="center"></td>';
	echo '<td class="right">'.price($total).'</td>';
	echo '<td class="right"></td>';
	echo '<td class="right"></td>';
	echo "</tr>\n";
}

echo "<!-- END PHP TEMPLATE -->\n";
